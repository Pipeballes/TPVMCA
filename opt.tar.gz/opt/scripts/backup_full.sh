#!/bin/bash

if [ "$1" = "-help" ]; then
 echo "Uso: backup_full.sh ORIGEN DESTINO"
 echo "Ejemplo: backup_full.sh /var/log /backup_dir"
 exit 0
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

if [ ! -d "$ORIGEN" ]; then
 echo "Error: el origen no existe"
 exit 1
fi

if [ ! -d "$DESTINO" ]; then
 echo "Error: el destino no existe"
 exit 1
fi

tar -czf "$DESTINO/${NOMBRE}_bkp_$FECHA.tar.gz" "$ORIGEN"

echo "backup generado correctamente"
