 poweroff
 poweroff
ps 'p 1
systemd
ps -p 1
ps -p 1
reboot
ps -p 1
ping -c 4
ping -c 4 google.com
apt update && apt upgrade -y
cat /etc/debian_version
cat /etc/debian_version
apt full-upgrade
reboot
cat /etc/debian_version
cat /etc/apt/sources.list
nano /etc/apt/sources.list
vi /etc/apt/sources.list
:q!
q
q1
q!
:q
nano
nano /etc/apt/sources.list
nano /etc/apt/sources.list
apt install nano -y
reboot
cat /etc/debian_version
nano /etc/apt/sources.list
nano
vi /etc/apt/sources.list
apt update
apt upgrade -y
apt full-upgrade -y
cat /etc/apt/sources.list
cat /etc/os-relese
vi /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/os-release
poweroff
hostnamectl
hostnamectl set hostname TPServer
hostnamectl set-hostname TPServer
hostname
hostnamectl
nano /etc/hosts
nano /etc/hosts
apt update
apt install nano -y
nano /etc/hosts
cat /etc/hosts
nano /etc/hosts
cat /etc/hosts
poweroff
apt install openssh-server
systemctl status ssh
q
sistemctl status ssh
systemctl status ssh
q
nano /etc/ssh/sshd_config
systemctl restart ssh
system status ssh
systemctl restart ssh
systemctl status ssh
/root/.ssh/authorized_keys
q
mkdir -p /root/.ssh
touch /root/.ssh/authorized_keys
ls -la /root/.ssh
clave_publica.pub
nano /root/.ssh/autorized_keys
cat /root/clave_publica.pub
find / -name "clave_publica.pub" 2
>/dev/null
find  / -name "clave_publica.pub" 2>/dev/null
nano /root/.ssh/authorizeddd_keys
cat > /root/.ssh/authorized_keys
find / -iname "*pub*" 2>/dev/null
find / -iname "*clave*" 2>/dev/null
 echo "" > /root/.ssh/autorized_keys
ssh-keygen
cat /root/.ssh/id_rsa.pub > /root/.ssh/authorized_keys
cat
poweroff
exit
systemctl status ssh
ssh -i /root/.ssh/id_rsa root@192.168.68.41
exit
poweroff
poweroff
apt install apache2 php libapache2-mod-php
systemctl status apache2
php -v
poweroff
ls -la/root
ls -la /root
nano /root/index.php
cat /root/index.php
touch /root/logo.png
ls -la /root
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls -la /var/www/html/
ip a
curl http://localhost
rm /var/www/html/index.html
curl http://localhost
ls -la /root
find / -iname "db.sql" 2>/dev/null
apt install mariadb-server
systemctl status mariadb
ls -la /root
cp /root/index.php /var/www/html/
cp /root/logo.png / var/www/html/
cp /root/logo.png /var/www/html/
ls -la /var/www/html
curl http://localhost
find / -iname "db.sql" 2>/dev/null
poweroff
nano /root/db.sql
cat > /root/db.sql
nano /root/db.sql
echo "CREATE DATABASE ingenieria;" > /root/db.sql
echo "USE ingenieria;" >> /root/db.sql
echo "CREATE USER 'lcars'@'%' IDENTIFIED BY 'NCC1701D';" >> /root/db.sql
echo "GRANT ALL PRIVILEGES ON ingenieria.* TO 'lcars'@'%';" >> /root/db.sql
cat /root/db.sql
nano /root/db.sql
apt install virtualbox-guest-utils virtualbox-guest-x11
apt instrall virtualbox-guest-utils
apt install virtualbox-guest-utils
apt install virtualbox-guest-additions-iso
reboot
nano /root/test.txt
nano /root/db.sql
nano /root/db.sql
nano /root/db.sql
tail /root/db.sql
mysql < /root/db.sql
nano /root/db.sql
mysql < /root/db.sql
nano /root/db.sql
mysql
mysql < /root/db.sql
nano /root/db.sql
mysql < /root/db.sql
mysql
mysql < /root/db.sql
mysql
ip a
poweroff
ip a
ip route
poweroff 
fdisk 
fdisk -1
fdisk -l
fdisk /dev/sda
lsblk
poweroff
lsblk
fdisk /dev/sdc
fdisk
fdisk /dev/sdc
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mk /backup_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
ls /
www_dir
backup_dir
mkfs.ext4 /dev/sdc1
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
nano /etc/fstab
mount -a
poweroff
ip a
ip route
cat /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
cat /etc/network/interfaces
reboot
ip a
ip route
ip a
ls -l /root
cp /root/index.php /www_dir/
cp /root/logo.png /www_dir/
ls -l /www_dir
cat /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
cat /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl status apache2
cat /proc/partitions > /opt/particion
cat /opt/particion
poweroff
